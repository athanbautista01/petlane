<!DOCTYPE html>
<html lang="en">

    <head>

        <title>Pet Lane | Pets</title>

        <?php
            //Connect to MySQL
            require_once("database/connect.php");
            //include the header
            include("include/header.php");
            unset($_SESSION["petpetid"]);
        ?>

        <section>
            <div class="container">
                <div class="col-lg-12 heading text-center">
                    <h2>PETS</h2>
                </div>
            </div>
        </section>
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <p class="bg-primary" align="center">Categories</p>

                        <?php
                            //include the count
                            include("include/count.php");
                        ?>
                        <!-- <div class="wellCategory"> -->
                        <ul class="list-group dropdown">
                            <li class="list-group-item">
                                <a href="pets.php" name="dogCategory"> <!--class="btn list-group-item"-->
                                    Dogs
                                    <span class="badge"><?php echo $dog; ?></span></a>
                            </li>
                            <li class="list-group-item">
                                <span class="badge"><?php echo $cat; ?></span>
                  Cats
                            </li>
                            <li class="list-group-item">
                                <span class="badge"><?php echo $fish; ?></span>
                  Fish
                            </li>
                            <li class="list-group-item">
                                <span class="badge"><?php echo $sm; ?></span>
                  Small Mammals
                            </li>
                            <li class="list-group-item">
                                <span class="badge"><?php echo $bird; ?></span>
                  Birds
                            </li>
                            <li class="list-group-item">
                                <span class="badge"><?php echo $repamp; ?></span>
                  Reptiles & Amphibians
                            </li>
                            <li class="list-group-item">
                                <span class="badge"><?php echo $equine; ?></span>
                  Equine
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-9">
                        <ul class="breadcrumb">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">Pets</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-9">

                        <p class="bg-primary" align="center">Pets</p>

                        <div class="col-sm-12">
                            <div class="row wellTools">
                                <div class="col-sm-3">
                                    <label>Sort by: </label>
                                    <select>
                                        <option value="">
                        Breed                </option>
                                        <option value="">
                          Name                </option>
                                        <option value="">
                            Price                </option>
                                    </select>
                                </div>
                            <form action="pets.php" method="post">
                                <div class="col-sm-offset-4 col-sm-5">
                                    <label>Display</label>
                                    <select name="displaySort" class="btn btn-default">
                                        <option value="" style="display:none;">Select</option>
                                        <option value="1" >
                              9                </option>
                                        <option value="2">
                                15                </option>
                                        <option value="3">
                                  30                </option>
                                    </select>
                                    <INPUT TYPE="submit" class="btn btn-primary" name="submit" value="Show" />
                                </div>
                            </form>
                            </div>
                            <?php
                                $limit = 2;
                                if (isset($_POST["submit"])) {
                                    $display = $_POST["displaySort"];

                                    if ($display == 1) {
                                        $limit=2;
                                    } else if ($display == 2) {
                                        $limit=4;
                                    } else if ($display == 3) {
                                        $limit=6;
                                    } 
                                } 

                                $start=0;
                                

                                if(isset($_GET['id']))
                                {
                                    $id=$_GET['id'];
                                    $start=($id-1)*$limit;
                                }
                                else{
                                    $id=1;
                                }
                                //Build the query to use to fetch records
                                $query = "SELECT a.PetID, a.CategoryID, a.Breed, a.Price, a.Available, PetBirthdate, a.Description, a.StatusID, a.UserID, 
                        a.PetName, a.Quantity, a.Reason, a.DateSold, a.Image, a.Image2, a.Image3, a.IsFeatured, b.CategoryID, 
                        b.Category, c.StatusID, c.Status FROM pet a INNER JOIN petcategory b ON a.CategoryID = b.CategoryID 
                        INNER JOIN petstatus c ON a.StatusID = c.StatusID  WHERE a.IsFeatured='Yes' LIMIT $start, $limit";
                        
                        //Fetch records from MySQL
                        $result = $conn->query($query); 
                        if ($conn->error) {
                          die("Query failed: " . $conn->error);
                        }
                                
                                
                                //If there are records fetched, iterate through the data set
                                if ($result->num_rows) {    
                                  while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 thumbnail">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <a href="include/petDetails.php?ID=<?php echo $row['PetID'] ?>" style="text-decoration: none;">
                                        <div class="hovereffect">
                                            <img class="img-responsive" src="<?php echo $row['Image'] ?>" alt="">
                                            <div class="overlay">
                                                <h2>Quick View</h2>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class=" text-center">
                                    <?php
                                        echo"<h3>" . $row["Breed"] . "</h3>
                                        <h4>P " . $row["Price"] . ".00 </h4>
                                        <div class='stat'><p>STATUS: " .$row["Status"]. "</p></div> ";
                                    ?>
                                </div>

                                <center>
                                    <a href="account/addToCart.php?ID=<?php echo $row['PetID'] ?>" class="btn btn-stylish" role="button" title="Add to Cart"><i class="fa fa-shopping-cart"></i></a>
                                    <a href="include/addToCart.php" class="btn btn-stylish" role="button" title="Add to Wishlist"><i class="fa fa-heart-o"></i></a>
                                </center>
                                <br>
                            </div>
                            <?php
                                }
                                } else {
                                  echo "No Pets.";
                                }
                                
                                
                            ?>
                        </div>
                        <?php
                            //fetch all the data from database.
                            $rows=mysqli_num_rows(mysqli_query($conn,"SELECT a.PetID, a.CategoryID, a.Breed, a.Price, a.Available, PetBirthdate, a.Description, a.StatusID, a.UserID, 
                        a.PetName, a.Quantity, a.Reason, a.DateSold, a.Image, a.Image2, a.Image3, a.IsFeatured, b.CategoryID, 
                        b.Category, c.StatusID, c.Status FROM pet a INNER JOIN petcategory b ON a.CategoryID = b.CategoryID 
                        INNER JOIN petstatus c ON a.StatusID = c.StatusID  WHERE a.IsFeatured='Yes'"));
                            //calculate total page number for the given table in the database 
                            $total=ceil($rows/$limit);
                        ?>
                        <div class="col-sm-offset-4 col-sm-8">
                            <ul class="pagination" align="center">
                            <?php if($id>1)
                                {
                                    //Go to previous page to show previous 10 items. If its in page 1 then it is inactive
                                    echo "<li><a href='?id=".($id-1)."'>&laquo;</a></li>";
                                }

                                //show all the page link with page number. When click on these numbers go to particular page. 
                                for($i=1;$i<=$total;$i++) {
                                    if($i==$id) { 
                                        echo "<li class='active'><a href='#'>".$i."</a></li>"; 
                                    }   else { 
                                        echo "<li><a href='?id=".$i."'>".$i."</a></li>"; 
                                    }
                                }
                                
                                if($id!=$total) {
                                    ////Go to previous page to show next 10 items.
                                    echo "<li><a href='".($id-1)."'>&raquo;</a></li>";
                                }

                            ?>
                                <!-- <li class="disabled"><a href="#">&laquo;</a></li>
                                <li class="active"><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#">4</a></li>
                                <li><a href="#">&raquo;</a></li> -->
                            </ul>
                        </div>
                    </div>
                </div>
                <!--</div>-->
            </div>
        </section>
        <?php
            include("html/footer.html");
        ?>
