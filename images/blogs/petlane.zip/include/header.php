<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<!-- FAVICON -->
<link rel="shortcut icon" type="image/x-icon" href="images/custom/favicon.ico">

<!-- Login JavaScript -->
<script src="js/login.js"></script>

<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="css/petline.css" rel="stylesheet">

<!-- Font-Awesome Fonts -->
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<!-- Custom Fonts -->
<link href="fonts/mont.css" rel="stylesheet" type="text/css">
<link href="fonts/lato.css" rel="stylesheet" type="text/css">


</head>
<body id="page-top" class="index">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php"><img class="img-responsive" src="images/custom/logo2.png" width="130px" alt=""></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">

                    <li class="page-scroll">
                        <div class="style">
                            <form action="search.php" method="post" role="search">
                                <?php
                                    include("js/search.php");
                                ?>
                            </form>
                        </div>
                    </li>
                    <?php
                        
                        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['qtd'] == 3) {
                            $userID = $_SESSION['userid'];

                            $cartCount = "select count(p.PetID) as CartCount from orderdetail od inner join pet p on od.petid = p.petid where od.status='InCart' AND od.UserID=$userID and od.userid=$userID";
                            $result = mysqli_query($conn, $cartCount);
                            while($row = $result->fetch_assoc()) {
                                $cart = $row['CartCount'];
                            }
                            echo "<li class='dropdown'>";
                            echo "  <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false' id='userPet'><div class='sep''>|</div>".$_SESSION['firstName']." <span class='cart'>".$cart."</span>&nbsp;<span class='caret'></span></a>";
                            echo "  <ul class='dropdown-menu'>";
                            echo "    <li><a href='account/cart.php'><i class='fa fa-shopping-cart'></i> Cart</a></li>";
                            echo "    <li><a href='account/checkout.php'><i class='fa fa-check-square-o'></i> Checkout</a></li>";
                            echo "    <li><a href='account/pending.php'><i class='fa fa-spinner'></i> Orders & Tracking</a></li>";
                        
                            echo "    <li role='separator' class='divider'></li>";
                            echo "    <li class='dropdown-header'>Profile Account</li>";
                            echo "    <li><a href='profile.php'><i class='fa fa-user'></i> Profile</a></li>";
                            echo "    <li><a href='account/wishlist.php'><i class='fa fa-heart-o'></i> Wishlist</a></li>";
                            echo "    <li align='center'><a href='include/logout.php'><button type='submit' class='btn btn-custom' onclick='location.href = 'index.php';'>Logout</button></a></li>";
                            echo "  </ul>";
                            echo "</li>";
                        
                        } else {
                            echo "<li class='page-scroll'><a href='register.php'><div class='sep'>|</div>LOG IN</a></li>";
                        }
                        
                    ?>
                                            <!-- <li class="page-scroll">
                                                                        <a href="register.php">|&ensp;&ensp;LOG IN</a>
                                                                    </li> -->
                    <li class="page-scroll">
                        <a href="aboutus.php"><div class="sep">|</div>ABOUT US</a>
                    </li>
                    <li class="page-scroll">
                        <a href="wikipets.php"><div class="sep">|</div>WIKIPETS</a>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="page-scroll">
                        <a href="index.php"><div class="sep"> </div><div class="homey1"><i class="fa fa-home fa-2xx"></i></div><div class="homey2">HOME</div></a>
                    </li>
                    <li class="page-scroll">
                        <a href="pets.php"><div class="sep">|</div>PETS</a>
                    </li>
                    <li class="page-scroll">
                        <a href="shop.php"><div class="sep">|</div>SHOP</a>
                    </li>
                    <li class="page-scroll">
                        <a href="sellpet.php"><div class="sep">|</div>SELL PET</a>
                    </li>
                    <li class="page-scroll">
                        <a href="appointment.php"><div class="sep">|</div>APPOINTMENT</a>
                    </li>
                    <li class="page-scroll">
                        <a href="blog.php"><div class="sep">|</div>BLOG</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
