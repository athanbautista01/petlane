<?php
    
    $dogCount = "SELECT COUNT(PetID) AS CategoryTot FROM pet where Categoryid ='1'";
    $result = mysqli_query($conn, $dogCount);
    while($row = $result->fetch_assoc()) {
        $dog = $row['CategoryTot'];
    }
    
    $catCount = "SELECT COUNT(PetID) AS CategoryTot FROM pet where Categoryid ='2'";
    $result = mysqli_query($conn, $catCount);
    while($row = $result->fetch_assoc()) {
        $cat = $row['CategoryTot'];
    }

    $fishCount = "SELECT COUNT(PetID) AS CategoryTot FROM pet where Categoryid ='3'";
    $result = mysqli_query($conn, $fishCount);
    while($row = $result->fetch_assoc()) {
        $fish = $row['CategoryTot'];
    }

    $smCount = "SELECT COUNT(PetID) AS CategoryTot FROM pet where Categoryid ='4'";
    $result = mysqli_query($conn, $smCount);
    while($row = $result->fetch_assoc()) {
        $sm = $row['CategoryTot'];
    }
    
    $birdCount = "SELECT COUNT(PetID) AS CategoryTot FROM pet where Categoryid ='5'";
    $result = mysqli_query($conn, $birdCount);
    while($row = $result->fetch_assoc()) {
        $bird = $row['CategoryTot'];
    }

    $repampCount = "SELECT COUNT(PetID) AS CategoryTot FROM pet where Categoryid ='6'";
    $result = mysqli_query($conn, $repampCount);
    while($row = $result->fetch_assoc()) {
        $repamp = $row['CategoryTot'];
    }

    $equineCount = "SELECT COUNT(PetID) AS CategoryTot FROM pet where Categoryid ='7'";
    $result = mysqli_query($conn, $equineCount);
    while($row = $result->fetch_assoc()) {
        $equine = $row['CategoryTot'];
    }
    
?>