<!DOCTYPE html>
<html lang="en">

    <head>

        <title>Pet Lane | Shop</title>
        <?php
            //Connect to MySQL
            require_once("database/connect.php");
            //include the header
            include("include/header.php");
        ?>

        <section>
            <div class="container">
                <div class="col-lg-12 heading text-center">
                    <h2>WELCOME TO THE SHOP!</h2>

                </div>
            </div>
        </section>
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <p class="bg-primary" align="center">Categories</p>
                        <?php
                            //include the count
                            //include("include/count.php");
                        ?>
                        <!-- <div class="wellCategory"> -->
                        <ul class="list-group dropdown">
                            <li class="list-group-item">
                                <span class="badge">14</span>
                  Dogs
                            </li>
                            <li class="list-group-item">
                                <span class="badge">2</span>
                  Cats
                            </li>
                            <li class="list-group-item">
                                <span class="badge">1</span>
                  Fish
                            </li>
                            <li class="list-group-item">
                                <span class="badge">14</span>
                  Small Mammals
                            </li>
                            <li class="list-group-item">
                                <span class="badge">2</span>
                  Birds
                            </li>
                            <li class="list-group-item">
                                <span class="badge">1</span>
                  Reptiles & Amphibians
                            </li>
                            <li class="list-group-item">
                                <span class="badge">14</span>
                  Equine
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-9">
                        <ul class="breadcrumb">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">Other Products</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-9">
                        <p class="bg-primary" align="center">Other Products</p>

                        <div class="col-sm-12">
                            <div class="row wellTools">
                                <div class="col-sm-3">
                                    <label>Sort by: </label>
                                    <select>
                                        <option value="">
                        Position                </option>
                                        <option value="">
                          Name                </option>
                                        <option value="">
                            Price                </option>
                                    </select>
                                </div>

                                <div class="col-sm-offset-7 col-sm-2">
                                    <label>Show</label>
                                    <select>
                                        <option value="" selected="selected">
                              9                </option>
                                        <option value="">
                                15                </option>
                                        <option value="">
                                  30                </option>
                                    </select>
                                </div>
                            </div>
                            <?php
                                //Build the query to use to fetch records
                                $query = "SELECT a.SuppliesID, a.CategoryID, a.ProductName, a.SuppliesCat, a.Brand, a.Price, a.Available, a.Description, a.Image2, a.Image3, a.Image, a.IsFeatured, b.CategoryID, b.Category FROM petsupplies a INNER JOIN petcategory b ON a.CategoryID = b.CategoryID WHERE IsFeatured='Yes' LIMIT 4";
                                
                                $result = $conn->query($query); 
                                if ($conn->error) {
                                die("Query failed: " . $conn->error);
                                }
                                
                                
                                //If there are records fetched, iterate through the data set
                                if ($result->num_rows) {    
                                while ($row = mysqli_fetch_assoc($result)) {
                                
                            ?>

                            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 thumbnail">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <a href="include/productDetails.php?ID=<?php echo $row['SuppliesID'] ?>" style="text-decoration: none;">
                                        <div class="hovereffect">
                                            <img src="<?php echo $row['Image'] ?>" class="img-responsive zoom-img" alt="">
                                            <div class="overlay">
                                                <h2>Quick View</h2>
                                            </div>
                                        </div>
                                    </a>
                                </div>

                                <div class=" text-center">
                                    <?php
                                        echo"<h3>" . $row["ProductName"] . "</h3>
                                        <h4>P " . $row["Price"] . "</h4>";
                                    ?>
                                </div>
                                <center>
                                    <a href="include/addToCart.php" class="btn btn-stylish" role="button" title="Add to Cart"><i class="fa fa-shopping-cart"></i></a>
                                    <a href="include/addToCart.php" class="btn btn-stylish" role="button" title="Add to Wishlist"><i class="fa fa-heart-o"></i></a>
                                </center>
                                <br>
                            </div>
                            <?php
                                }
                                } else {
                                  echo "No Pets.";
                                }
                                
                                $conn->close();
                            ?>
                        </div>
                        <div class="col-sm-offset-4 col-sm-8">
                            <ul class="pagination" align="center">
                                <li class="disabled"><a href="#">&laquo;</a></li>
                                <li class="active"><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#">4</a></li>
                                <li><a href="#">&raquo;</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--</div>-->
            </div>
        </section>
        <?php
            include("html/footer.html");
        ?>
