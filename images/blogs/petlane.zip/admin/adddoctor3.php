<!DOCTYPE html>
<html lang="en">

<head>

  <title>Pet Lane | Doctor</title>


<?php 
	
    include("includeHeader.php");
  require_once("../database/connect.php");



	$firstName = $_POST["firstName"];
	$lastName = $_POST["lastName"];
	$address = $_POST["address"];
	$contactNo = $_POST["contactNo"];
	$hospital = $_POST["hospital"];
	$degree = $_POST["degree"];
	$school = $_POST["school"];
	$experience = $_POST["experience"];
	$boardCertificate = $_POST["boardCertificate"];
	$award = $_POST["award"];
	$additionalInfo = $_POST["additionalInfo"];

	 	$file_name=$_FILES["image"]["name"];
        $temp_name=$_FILES["image"]["tmp_name"];
        $imgtype=$_FILES["image"]["type"];
        $target_path = "../images/doctor/".$file_name;



	$selectQuery = "SELECT Userlistid FROM userlist ORDER BY userlistid DESC LIMIT 1;";

	$result = mysqli_query($conn, $selectQuery);

	while($row = $result->fetch_assoc()) {
		$UserListID = $row['Userlistid'];
	}

	if(move_uploaded_file($temp_name, $target_path)) {
	$query = "INSERT INTO doctor (userlistid, lastName,firstName, address, contactno,hospital,degree,schoolgraduated,experience,boardcertification,awards,photo,additionalInfo,status) VALUES ('$UserListID', '$lastName', '$firstName', '$address', '$contactNo','$hospital', '$degree', '$school', '$experience', '$boardCertificate', '$award', '$file_name','$additionalInfo', 'Active');";


	if ($conn->query($query) === TRUE) {			//Check if operation was successful
	$message = "Created user with ID: " . $conn->insert_id;
	} else {
		die ("Insert failed: ". $conn->error);		//Retrieve any error in the operation
	}	

		}

?>

  <section>
            <div class="container">
                <div class="col-lg-12">
                    <div class="well bs-component">
                        <div class="form-horizontal">
                            <fieldset>
                                <!-- <legend><h1><b></h1></legend> -->
                                <div class="col-lg-offset-2 col-lg-8">
                                    <div class="panel panel-success">
                                        <div class="panel-heading" align="center"><h4><b>Success</b></h4></div>
                                        <div class="panel-body">

                                            <p align="center"><a href="../index.php" class="btn btn-outline">Click here to go back</a></p>

                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                </div>
            </div>
        </section>


<?php

    include("../include/includeFooter.html");    
?>