<?php
    //Connect to MySQL and validate userid
            include("requiredLogin.php");
    //include the header
    include("includeHeader.php");
    $qid = $_SESSION['userid']
?>

<section>
    <div class="container">
        <div class="col-lg-12 heading text-center"><br>
            <h2>Pet Supplies</h2>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <?php include("navigation.php");?>
                <div class="col-lg-9">
                    <div class="panel panel-success">
                        <div class="panel-heading" align="center"><h4><b></b></h4></div>
                        <div class="panel-body">
                            <?php
                                //Build the query to use to fetch records
                                        $query = "SELECT a.UserID, a.UserListID, a.LastName, a.FirstName, a.Address, a.Photo, a.ContactNo, a.AdditionalInfo, 
                                        a.Status,b.UserListID, b.UserTypeID, b.Password, b.Username, b.Email, b.DateAdded
                                        FROM user a INNER JOIN userlist b ON a.UserListID = b.UserListID WHERE a.UserID=$qid";
                                        //Fetch records from MySQL
                                        $result = $conn->query($query); 
                                        if ($conn->error) {
                                          die("Query failed: " . $conn->error);
                                        }
                                        //If there are records fetched, iterate through the data set
                                        if ($result->num_rows) {    
                                          while ($row = mysqli_fetch_assoc($result)) { 
                            ?>

                            <?php
                                }}
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <div class="scroll-top page-scroll hidden-lg hidden-md" style="display: block;">
        <a class="btn btn-primary" href="#page-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>

    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
</body>

</html>
