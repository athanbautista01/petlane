<div class="col-lg-3">
    <ul class="list-group">
        <a href="profile.php"><li class="list-group-item active">Profile</li></a><!--<a href="profile.php"></a>-->
        <a href="editprofile.php?ID=<?php echo $_SESSION['userid'] ?>"><li class="list-group-item">Edit Profile</li></a>
        <a href="ca.php"><li class="list-group-item">Customers & Admin</li></a>
        <a href="vets.php"><li class="list-group-item">Veterinarians</li></a>
        <a href="appointment.php"><li class="list-group-item">Appointments</li></a>
        <a href="cs.php"><li class="list-group-item">Pet Categories & Status</li></a>
        <a href="pets.php"><li class="list-group-item">Pets</li></a>
        <a href="petSupplies.php"><li class="list-group-item"> Pet Supplies</li></a>
        <a href="reviews.php"><li class="list-group-item">Reviews</li></a>
        <a href="blogs.php"><li class="list-group-item">Blogs</li></a>
        <a href="comments.php"><li class="list-group-item">Comments</li></a>
        <a href="deliveries.php"><li class="list-group-item">Orders & Deliveries</li></a>
    </ul>
</div>