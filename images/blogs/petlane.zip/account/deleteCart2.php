<?php
    //Connect to MySQL and validate userid
    include("requiredLogin.php");
    
    if(isset($_GET['ID'])) {
    $RefNo = $_GET['ID'];
    
    $query = "DELETE FROM orderdetail WHERE RefNo='$RefNo'";
    
        //Insert new student into MySQL
        if ($conn->query($query) === TRUE) {
?>
<script>
    alert('Successfully Deleted!.');
    window.location.href='checkout.php';
</script>
<?php
    } else {
?>
<script>
    alert('Error while deleting incart pet/pet supplies.');
    window.location.href='checkout.php';
</script>
<?php
            die ("Deleted failed: ". $conn->error);
        }
    }
?>
