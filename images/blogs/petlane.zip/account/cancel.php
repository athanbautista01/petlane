<?php

	echo "Your Payment was cancelled";

?>