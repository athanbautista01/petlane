<?php
    //Connect to MySQL and validate userid
    include("requiredLogin.php");
    
    if(isset($_GET['ID'])) {
    $RefNo = $_GET['ID'];
    $qty = $_POST["qty"];

    $query = "SELECT od.RefNo, p.PetID, p.Image, p.Breed, p.PetName, p.Price, od.Quantity, od.Amount, od.Status from orderdetail od inner join pet p on od.PetID = p.PetID WHERE od.RefNo='$RefNo'";
    $result = $conn->query($query); 
    if ($result->num_rows) {    
       while ($row = mysqli_fetch_assoc($result)) {
           $price = $row['Price'];
       }
    }
    
    $amount = $qty * $price;
    $query = "UPDATE orderdetail SET Amount='$amount', Quantity='$qty' WHERE RefNo='$RefNo'";
    
        //Insert new student into MySQL
        if ($conn->query($query) === TRUE) {
?>
<script>
    //alert('Successfully Deleted!.');
    window.location.href='checkout.php';
</script>
<?php
    } else {
?>
<script>
    alert('Error while updating incart pet/pet supplies.');
    window.location.href='checkout.php';
</script>
<?php
            die ("Deleted failed: ". $conn->error);
        }
    }
?>
