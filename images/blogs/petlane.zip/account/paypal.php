
<?php
            //Connect to MySQL and validate userid
            include("requiredLogin.php");
        ?>

<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">
    <input type="hidden" name="cmd" value="_xclick">
    <input type="hidden" name="business" value="jonathanbautista1997@gmail.com">
    <?php
        $userID = $_SESSION['userid'];
        //Build the query to use to fetch records
        $query = "select od.refno, p.petid, p.image, p.breed, p.petname, p.price, od.quantity, od.amount from orderdetail od inner join pet p on od.petid = p.petid where od.UserID='2'";
        
        //Fetch records from MySQL
        $result = $conn->query($query); 
        if ($conn->error) {
          die("Query failed: " . $conn->error);
        }
        
        
        //If there are records fetched, iterate through the data set
        if ($result->num_rows) {    
          while ($row = mysqli_fetch_assoc($result)) {
            $_SESSION['updpetid'] = $row['petid'];
        
    ?>

    <input type="hidden" name="item_name" value="<?php echo $row['breed'] ?>">
    <input type="hidden" name="item_number" value="<?php echo $row['petid'] ?>">
    <input type="hidden" name="amount" value="<?php echo $row['price'] ?>">
    <!--<input type="hidden" name="tax" value="1">-->
    <input type="hidden" name="quantity" value="<?php echo $row['quantity'] ?>">
    <?php
        }
        } else {
          echo "<tr>
            <td colspan='6'>
                <h3 class='text-center'>No items found.</h3>
            </td>
        </tr>";
        }
        
        
    ?>
    <input type="hidden" name="no_note" value="1">
    <input type="hidden" name="currency_code" value="PHP">
    <!-- Enable override of payer's stored PayPal address -->
    <input type="hidden" name="address_override" value="1">
    <!-- Set prepopulation variables to override stored address -->
            <!-- <input type="hidden" name ="custom_creator_id" value="555">
                    <input type="hidden" name ="custom_type" value="deposit">
                    <input type="hidden" name ="custom_description" value="testdesc">
                    <input type="hidden" name ="custom_payment_gateway_id" value="11">
                    <input type="hidden" name ="custom_user_type" value="2">-->
    <input type="hidden" name="first_name" value="John">
    <input type="hidden" name="last_name" value="Doe">
    <input type="hidden" name="address1" value="345 Lark Ave">
    <input type="hidden" name="city" value="San Jose">
    <input type="hidden" name="state" value="CA">
    <input type="hidden" name="zip" value="95121">
    <input type="hidden" name="country" value="US">

    <input type="hidden" name="notify_url" value="http://localhost:8088/projects/paypal/ipnlistener.php">
    <input type="hidden" name="return" value="http://localhost:8088/projects/paypal/paymentSuccess.php">
    <input type="hidden" name="cancel_return" value="http://localhost:8088/projects/paypal/cancel.php">

    <input type="image" name="submit" border="0" src="https://www.paypal.com/en_US/i/btn/btn_buynow_LG.gif" alt="PayPal - The safer, easier way to pay online">
</form>




















<?php
    /*$services = array('http', 'ftp', 'ssh', 'telnet', 'imap', 'smtp', 'nicname', 'gopher', 'finger', 'pop3', 'www');
    
    foreach ($services as $service) {
        $port = getservbyname($service, 'tcp');
        echo $service . ":- " . $port . "<br />\n";
    }*/
?>

<?php
     //echo $value = getservbyport(3306, "http");
    
    //echo $_SERVER['SERVER_PORT'] ;
    
?> 