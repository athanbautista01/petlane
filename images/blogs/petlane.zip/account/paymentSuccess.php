<?php

	echo "Thank you for your payment";

?>