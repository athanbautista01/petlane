<?php
    //Connect to MySQL and validate userid
    include("requiredLogin.php");
    
    if(isset($_GET['ID'])) {
    $petID = $_GET['ID'];
    
    if (isset($_POST["qty"])) {
        $qty = $_POST["qty"];
    } else {
        $qty = 1;
    }
    
    //$petID = $_SESSION['petpetid'];
    
    $price = 0;
    
    $userID = $_SESSION['userid'];
    // $insertQuery = "INSERT INTO orders(dateordered, paymentmethod, status) VALUES('2016-00-00', 'Cash on Delivery', 'Pending');";
    
    //     if ($conn->query($insertQuery) === TRUE) {          //Check if operation was successful
    //         $message = "Created user with ID: " . $conn->insert_id;
    //     } else {
    //         die ("Insert failed: ". $conn->error);      //Retrieve any error in the operation
    //     }   
    
    $selectQuery = "SELECT orderno FROM orders ORDER BY orderno DESC LIMIT 1;";
    
        $result1 = mysqli_query($conn, $selectQuery);
    
        while($row = $result1->fetch_assoc()) {            
            $sample = $row['orderno'];
        }
    
    $selectQuery1 = "SELECT price FROM pet where petid='$petID';";
    
        $result2 = mysqli_query($conn, $selectQuery1);
    
        while($row = $result2->fetch_assoc()) {            
            $price = $row['price'];
    
        }
    
    $total = $price * $qty;
    
    $query = "INSERT INTO orderdetail (orderno, userid, petid, quantity, amount, status) VALUES ('1', '$userID', '$petID', '$qty', '$total', 'InCart')";
    
        //Insert new student into MySQL
        if ($conn->query($query) === TRUE) {            //Check if operation was successful
    
            $message = "Created user with ID: " . $conn->insert_id;
        } else {
            die ("Insert failed: ". $conn->error);      //Retrieve any error in the operation
        }   
    
    }
    // echo "order".$sample;
    // echo "user".$userID;
    // echo "pet".$petID;
    // echo "qty".$qty;
    // echo "price".$price;
    // echo "total".$total;
    
    
?>
<script>
    //window.location.href='../pets.php';
    window.location.href='cart.php';
</script>