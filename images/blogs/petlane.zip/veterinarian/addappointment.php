<?php
    include("requiredLogin.php");
    //Connect to MySQL
    require_once("../database/connect.php");
    
                   $userlistidone = $_SESSION['userlistidone']; // doctor
                   $userlistidtwo = $_SESSION['userlistid']; // user
                    $date = $_POST["date"];
                   $reason = $_POST["reason"];
                   $oras = $_POST["time"];
                  $ngayon = getdate();
                  $insert = "INSERT INTO appointment(useroneid,usertwoid,date,time,reason,dateadded) VALUES($userlistidone,$userlistidtwo,'$date','$oras','$reason',NOW())";
    
                    if ($conn->query($insert) === TRUE) {          //Check if operation was successful
                    $message = "Created user with ID: " . $conn->insert_id;
                     } else {
                            die ("Insert failed: ". $conn->error);      //Retrieve any error in the operation
                    }
    
    
                      echo "$date";
?>