<div class="col-lg-3">
    <ul class="list-group">
        <a href="profile.php"><li class="list-group-item active">Profile</li></a><!--<a href="profile.php"></a>-->
        <a href="editprofile.php?ID=<?php echo $_SESSION['userid'] ?>"><li class="list-group-item">Edit Profile</li></a>
        <a href="addappointment.php"><li class="list-group-item">Add Appointment/s</li></a>
        <a href="appointment.php"><li class="list-group-item">View Appointments</li></a>
    </ul>
</div>