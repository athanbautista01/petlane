<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Pet Lane | Wikipets</title>
        <?php
            //Connect to MySQL
            require_once("database/connect.php");
            //include the header
            include("include/header.php");
        ?>
        <section>
            <div class="container">
                <div class="col-lg-12 heading text-center">
                    <h2>WIKIPETS</h2>
                </div>

                <div class="row">
                    <div class="col-md-7">

                        <div class="text-left">
                            <h2>What is a pet?</h2>
                            <br>
                            <p>A pet or companion animal is an animal kept primarily for a person's company or protection, as opposed to working animals, sport animals, livestock, and laboratory animals, which are kept primarily for performance, agricultural value, or research. The most popular pets are noted for their attractive appearances and their loyal or playful personalities.</p>

                            <br>
                            <br>


                        </div>
                        <br>
                    </div>
                    <div class="col-md-3 portfolio-item bg">
                        <br>
                        <img src="images/wikipets/cat_dog.jpg" class="img-responsive" alt="">

                        <div class=" text-center">
                            <p>A cat and dog, two popular pets.</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3">
                        <div class="well well-lg">
                            <h4>Contents</h4>
                            <p>Legalities</p>
                            <p>Pet popularity</p>
                            <p>Choice of a pet</p>
                            <p>Overpopulation</p>
                            <p>Effects on pet's health</p>
                            <p>Effects of pets on their caregiver's health</p>
                            <p>Common types of pets</p>
                            <p>History</p>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <h3>Pet popularity</h3>
                        <p>The two most popular pets in most Western countries have been cats and dogs. In the United States, a 2007�2008 survey showed that dog-owning households outnumbered those owning cats, but that the total number of pet cats was higher than that of dogs.In 2013, pets outnumbered children four to one in the United States.</p>

                        <br>
                        <h4 align="center">Most Popular Pets in the U.S.(millions)</h4>
                        <br>
                        <table style="width:100%" align="center">
                            <tr align="center">
                                <td><b>Pet</b></td>
                                <td><b>Global population</b></td>
                                <td><b>U.S. Population</b></td>
                                <td><b>U.S. Inhabited households</b></td>
                                <td><b>U.S. average per inhabited household</b></td>
                            </tr>
                            <tr align="center">
                                <td>Dog</td>
                                <td>171</td>
                                <td>77.5</td>
                                <td>45.6</td>
                                <td>1.70</td>
                            </tr>
                            <tr align="center">
                                <td>Cat</td>
                                <td>202</td>
                                <td>93.6</td>
                                <td>38.2</td>
                                <td>2.45</td>
                            </tr>
                            <tr align="center">
                                <td>Bird</td>
                                <td>N/A</td>
                                <td>15.0</td>
                                <td>6.0</td>
                                <td>2.50</td>
                            </tr>
                            <tr align="center">
                                <td>Reptiles & Amphibians</td>
                                <td>N/A</td>
                                <td>13.6</td>
                                <td>4.7</td>
                                <td>2.89</td>
                            </tr>
                            <tr align="center">
                                <td>Small Mammals</td>
                                <td>N/A</td>
                                <td>15.9</td>
                                <td>5.3</td>
                                <td>3.00</td>
                            </tr>
                            <tr align="center">
                                <td>Equine</td>
                                <td>N/A</td>
                                <td>13.3</td>
                                <td>3.9</td>
                                <td>3.41</td>
                            </tr>
                            <tr align="center">
                                <td>Fish</td>
                                <td>N/A</td>
                                <td>171.7</td>
                                <td>13.3</td>
                                <td>12.86</td>
                            </tr>
                        </table>

                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-2 portfolio-item bg">
                        <br>
                        <img src="images/wikipets/cat.png" class="img-responsive" alt="">
                        <p align="center">Kitten</p>
                        <br>
                        <img src="images/wikipets/pig.jpg" class="img-responsive" alt="">
                        <p align="center">Guinea Pigs</p>
                        <br>
                        <img src="images/wikipets/labrador.jpg" class="img-responsive" alt="">
                        <p align="center">Pet Labrador</p>
                        <br>
                        <img src="images/wikipets/puppy.jpg" class="img-responsive" alt="">
                        <p align="center">Maltese Puppy</p>
                    </div>

                    <div class="col-md-8">

                        <div class="text-left">
                            <h3>Choice of a pet</h3>
                            <p>For a small to medium-size dog, the total cost over a dog's lifetime is about $7,240 to $12,700.For an indoor cat, the total cost over a cat's lifetime is about $8,620 to $11,275.People most commonly get pets for companionship, to protect a home or property, or because of the beauty or attractiveness of the animals.The most common reasons for not owning a pet are lack of time, lack of suitable housing, and lack of ability to care for the pet when traveling.</p>
                            <h3>Overpopulation</h3>
                            <p>Animal protection advocates call attention to pet overpopulation. According to the Humane Society of the United States, animal shelters care for about 6 to 8 million dogs and cats each year, but approximately 3 to 4 million are euthanized.</p>
                            <h3>Effects on pets health</h3>
                            <p>Keeping animals as pets may be detrimental to their health if certain requirements are not met. An important issue is inappropriate feeding, which may produce clinical effects. The consumption of chocolate or grapes by dogs, for example, may prove fatal.</p>
                            <h3>Effects of pets on their caregiver's health</h3>
                            <p>Pets might have the ability to stimulate their caregivers, in particular the elderly, giving people someone to take care of, someone to exercise with, and someone to help them heal from a physically or psychologically troubled past.</p>

                        </div>
                    </div>

                </div>
                <br>
                <div class="row">
                    <h3>Common Types</h3>
                    <p>While many people have kept many different species of animals in captivity over the course of human history, only a relative few have been kept long enough to be considered domesticated. Other types of animals, notably monkeys, have never been domesticated but are still commonly sold and kept as pets. There are also inanimate objects that have been kept as "pets", either as a form of game, or humorously (e.g. the Pet Rock or Chia Pet).</p>
                    <h3>History</h3>
                    <p>Archeology suggests that dogs as pets may date back to at least 12,000 years ago.</p>
                </div>

                <br>
                <br>
                <div class="row">
                    <h3>Our Pets</h3>
                    <div class="col-sm-3 portfolio-item bg">

                        <div class=" text-center">
                            <h4>SHITH-TZU</h4>
                        </div>
                        <center>
                            <a href="html/wikipet1.html" class="btn btn-outline" role="button">Read</a>
                        </center>
                        <br>
                    </div>
                    <div class="col-sm-3 portfolio-item bg">
                        <div class=" text-center">
                            <h4>SPHYNX</h4>
                        </div>
                        <center>
                            <a href="html/wikipet2.html" class="btn btn-outline" role="button">Read</a>
                        </center>
                        <br>
                    </div>
                    <div class="col-sm-3 portfolio-item ba">
                        <div class=" text-center">
                            <h4>BULLDOG</h4>
                        </div>
                        <center>
                            <a href="html/wikipet3.html" class="btn btn-outline" role="button">Read</a>
                        </center>
                        <br>
                    </div>
                </div>
                <br><br><br><br><br>
            </div>
        </section>

        <?php
            include("html/footer.html");
        ?>

