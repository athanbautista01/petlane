-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2016 at 08:16 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petlane`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `AppointmentID` int(11) NOT NULL,
  `UserOneID` int(11) NOT NULL,
  `UserTwoID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Time` varchar(50) NOT NULL,
  `Reason` varchar(300) NOT NULL,
  `DateAdded` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`AppointmentID`, `UserOneID`, `UserTwoID`, `Date`, `Time`, `Reason`, `DateAdded`) VALUES
(15, 4, 3, '2016-03-25', '00:25', 'joseph', '2016-03-24'),
(19, 101, 2, '2016-04-22', '17:02', 'asas', '2016-04-03'),
(20, 5, 1, '2016-04-01', '03:13', 'asfasfasfasfasfasfasfasfas safsafasfasfas', '2016-04-03'),
(21, 943, 2, '2016-03-29', '00:12', '121212121', '2016-04-03');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `BlogID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Image` varchar(400) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Content` varchar(10000) NOT NULL,
  `DateAdded` date NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`BlogID`, `UserID`, `Image`, `Title`, `Content`, `DateAdded`, `Status`) VALUES
(1, 1, 'images/blogs/Pets.jpg', 'Best Pets of Today', 'Every dog knows that he needs to keep up to date with the news from the canine world. He understands the importance of learning more about where other dogs live, how they train their humans, and how to stay in touch with fellow dogs from all over the world.\r\nIn reality, of course the days are short and there are lamp posts to sniff, balls to chase and mud puddles to roll around in and it is not easy to stay on top of everything.\r\nSo to help my canine friends out there to stay in touch and up to date I have compiled a list of the very best dog blogs and websites I could find. I wanted to call it Alfies ultimate list of dog blogs or the best dog blogs ever or even compulsory reading for dogs and puppies of all ages, but in the end I settled for top dog blogs and I think that covers it!\r\n\r\n', '2016-03-16', 'Approve'),
(2, 2, 'images/blogs/dog-park-mom.jpg', 'Favorite Pet Blog', 'So to help my canine friends out there to stay in touch and up to date I have compiled a list of the very best dog blogs and websites I could find. I wanted to call it Alfies ultimate list of dog blogs or the best dog blogs ever or even compulsory reading for dogs and puppies of all ages, but in the end I settled for top dog blogs and I think that covers it! I will add links whenever I find new and exciting blogs out there, so please come back regularly. Enjoy your reading and if you are a new friend of mine and would like your blog added to my list, then please leave a comment below and I will get in touch as soon as I have finished my dinner.', '2016-03-08', 'Approve'),
(3, 5, 'images/blogs/blog1.jpg', 'How to Train Your Dog to Wear a Costume', 'No vel nonumy viderer. Duo pertinax cotidieque at, eum te integre detraxit philosophia, quando dictas mea an. Putent nostrud in per, reque persequeris sea ad. At mei graeci cotidieque neglegentur, id ius omittam commune suscipiantur. Ne his tamquam percipit expetenda, soleat omittam ea sea.<br><br>\n\nVel et aliquam molestie, vix ea noster verear. Sea ei tollit urbanitas. Ne erat nemore duo, alia probatus vis at, cibo libris deserunt ea mei. Ex his nonumes dignissim.<br><br>\n\nHas at quod malis, ad tollit oportere duo. Sint soluta iriure ad eos, fuisset theophrastus et nec. Vero facilis ei mea, porro patrioque consectetuer eu pro. Cu graeco aeterno recusabo cum.<br><br>\n\nHas ad enim erat vituperata, mei magna fuisset an, sit an numquam singulis. Nec te magna dissentias, dictas eloquentiam sit cu. In sumo conceptam per, suscipit voluptatum ius et, eu mel augue partiendo suavitate. Te dico voluptaria pri, ea mel enim omnium noluisse, sint omnes principes eu quo. Ut commodo utroque mentitum quo, elitr doctus ut mei, quando vocibus ad qui.<br><br>\n\nIn tritani hendrerit consectetuer duo. Illud errem sed ea, ex eam erant doming viderer. Cum utinam veritus offendit in. Te iusto indoctum conceptam mel. Ei nihil accusam iudicabit nec. Vix id erat prima dissentiunt.<br><br>\n\nCommodo maiorum dissentiunt usu ne, sint pertinacia sea ut, sed eu perfecto honestatis. No consequat disputationi ius, an wisi iudicabit inciderint pro, diam atqui ei mea. Ea quis sumo elit eos, eam vero consequat contentiones ei. Has ex omnesque partiendo posidonium, pri ea natum fugit libris.<br><br>\n\nUsu unum quando deseruisse at. Eu qui graecis suavitate, minim pertinax ex eum. Id vis impedit delectus perfecto, cum illud fastidii aliquando ea, summo novum atomorum vis te. Sed solum putent id, usu cu nemore debitis oportere, nihil utroque principes mei ea.<br><br>\n\nIus ad verear pertinax evertitur, cu qui rebum inani malorum, dicit soluta corrumpit nam an. Id placerat ocurreret vis, ut cum fugit fastidii evertitur, nam labitur periculis at. Eum cu interpretaris necessitatibus. Et exerci oportere sit, quem ferri evertitur mel an.<br><br>\n\nNam id voluptaria disputando. Vim ne agam assentior, agam intellegat concludaturque eu vix. Eam ad alienum albucius, te duo oratio doming hendrerit. Pro et assum audiam deseruisse, qui vitae viderer assentior ne, in sea graeco molestiae. Nam nisl volutpat ad, no vim facer paulo dolores.<br><br>\n\nEt his solet epicurei. Alienum insolens volutpat ius at, saepe nominavi oporteat an ius. Facete civibus ea vix, ad eam perfecto adipiscing reprimique. Quo aperiam adipisci te, ipsum animal eum ex. In meis simul oportere mel, ut modus admodum mel.', '2016-04-02', 'Approve'),
(4, 2, 'images/blogs/post3.jpg', 'Dog Training Tips â€“ How To Train a Dog', 'No vel nonumy viderer. Duo pertinax cotidieque at, eum te integre detraxit philosophia, quando dictas mea an. Putent nostrud in per, reque persequeris sea ad. At mei graeci cotidieque neglegentur, id ius omittam commune suscipiantur. Ne his tamquam percipit expetenda, soleat omittam ea sea.\n<br><br>\nVel et aliquam molestie, vix ea noster verear. Sea ei tollit urbanitas. Ne erat nemore duo, alia probatus vis at, cibo libris deserunt ea mei. Ex his nonumes dignissim.\n<br><br>\nHas at quod malis, ad tollit oportere duo. Sint soluta iriure ad eos, fuisset theophrastus et nec. Vero facilis ei mea, porro patrioque consectetuer eu pro. Cu graeco aeterno recusabo cum.\n<br><br>\nHas ad enim erat vituperata, mei magna fuisset an, sit an numquam singulis. Nec te magna dissentias, dictas eloquentiam sit cu. In sumo conceptam per, suscipit voluptatum ius et, eu mel augue partiendo suavitate. Te dico voluptaria pri, ea mel enim omnium noluisse, sint omnes principes eu quo. Ut commodo utroque mentitum quo, elitr doctus ut mei, quando vocibus ad qui.\n<br><br>\nIn tritani hendrerit consectetuer duo. Illud errem sed ea, ex eam erant doming viderer. Cum utinam veritus offendit in. Te iusto indoctum conceptam mel. Ei nihil accusam iudicabit nec. Vix id erat prima dissentiunt.\n<br><br>\nCommodo maiorum dissentiunt usu ne, sint pertinacia sea ut, sed eu perfecto honestatis. No consequat disputationi ius, an wisi iudicabit inciderint pro, diam atqui ei mea. Ea quis sumo elit eos, eam vero consequat contentiones ei. Has ex omnesque partiendo posidonium, pri ea natum fugit libris.\n<br><br>\nUsu unum quando deseruisse at. Eu qui graecis suavitate, minim pertinax ex eum. Id vis impedit delectus perfecto, cum illud fastidii aliquando ea, summo novum atomorum vis te. Sed solum putent id, usu cu nemore debitis oportere, nihil utroque principes mei ea.\n<br><br>\nIus ad verear pertinax evertitur, cu qui rebum inani malorum, dicit soluta corrumpit nam an. Id placerat ocurreret vis, ut cum fugit fastidii evertitur, nam labitur periculis at. Eum cu interpretaris necessitatibus. Et exerci oportere sit, quem ferri evertitur mel an.\n<br><br>\nNam id voluptaria disputando. Vim ne agam assentior, agam intellegat concludaturque eu vix. Eam ad alienum albucius, te duo oratio doming hendrerit. Pro et assum audiam deseruisse, qui vitae viderer assentior ne, in sea graeco molestiae. Nam nisl volutpat ad, no vim facer paulo dolores.\n<br><br>\nEt his solet epicurei. Alienum insolens volutpat ius at, saepe nominavi oporteat an ius. Facete civibus ea vix, ad eam perfecto adipiscing reprimique. Quo aperiam adipisci te, ipsum animal eum ex. In meis simul oportere mel, ut modus admodum mel.', '2016-04-02', 'Approve'),
(5, 2, 'images/blogs/post5.jpg', '8 Sports Your Dog Can Play', 'No vel nonumy viderer. Duo pertinax cotidieque at, eum te integre detraxit philosophia, quando dictas mea an. Putent nostrud in per, reque persequeris sea ad. At mei graeci cotidieque neglegentur, id ius omittam commune suscipiantur. Ne his tamquam percipit expetenda, soleat omittam ea sea.\r\n<br><br>\r\nVel et aliquam molestie, vix ea noster verear. Sea ei tollit urbanitas. Ne erat nemore duo, alia probatus vis at, cibo libris deserunt ea mei. Ex his nonumes dignissim.\r\n<br><br>\r\nHas at quod malis, ad tollit oportere duo. Sint soluta iriure ad eos, fuisset theophrastus et nec. Vero facilis ei mea, porro patrioque consectetuer eu pro. Cu graeco aeterno recusabo cum.\r\n<br><br>\r\nHas ad enim erat vituperata, mei magna fuisset an, sit an numquam singulis. Nec te magna dissentias, dictas eloquentiam sit cu. In sumo conceptam per, suscipit voluptatum ius et, eu mel augue partiendo suavitate. Te dico voluptaria pri, ea mel enim omnium noluisse, sint omnes principes eu quo. Ut commodo utroque mentitum quo, elitr doctus ut mei, quando vocibus ad qui.\r\n<br><br>\r\nIn tritani hendrerit consectetuer duo. Illud errem sed ea, ex eam erant doming viderer. Cum utinam veritus offendit in. Te iusto indoctum conceptam mel. Ei nihil accusam iudicabit nec. Vix id erat prima dissentiunt.\r\n<br><br>\r\nCommodo maiorum dissentiunt usu ne, sint pertinacia sea ut, sed eu perfecto honestatis. No consequat disputationi ius, an wisi iudicabit inciderint pro, diam atqui ei mea. Ea quis sumo elit eos, eam vero consequat contentiones ei. Has ex omnesque partiendo posidonium, pri ea natum fugit libris.\r\n<br><br>\r\nUsu unum quando deseruisse at. Eu qui graecis suavitate, minim pertinax ex eum. Id vis impedit delectus perfecto, cum illud fastidii aliquando ea, summo novum atomorum vis te. Sed solum putent id, usu cu nemore debitis oportere, nihil utroque principes mei ea.\r\n<br><br>\r\nIus ad verear pertinax evertitur, cu qui rebum inani malorum, dicit soluta corrumpit nam an. Id placerat ocurreret vis, ut cum fugit fastidii evertitur, nam labitur periculis at. Eum cu interpretaris necessitatibus. Et exerci oportere sit, quem ferri evertitur mel an.\r\n<br><br>\r\nNam id voluptaria disputando. Vim ne agam assentior, agam intellegat concludaturque eu vix. Eam ad alienum albucius, te duo oratio doming hendrerit. Pro et assum audiam deseruisse, qui vitae viderer assentior ne, in sea graeco molestiae. Nam nisl volutpat ad, no vim facer paulo dolores.\r\n<br><br>\r\nEt his solet epicurei. Alienum insolens volutpat ius at, saepe nominavi oporteat an ius. Facete civibus ea vix, ad eam perfecto adipiscing reprimique. Quo aperiam adipisci te, ipsum animal eum ex. In meis simul oportere mel, ut modus admodum mel.', '2016-04-02', 'Approve'),
(6, 2, 'images/blogs/post11.jpg', 'Cat Health Care | Veterinary Advice For Cat Owners', 'No vel nonumy viderer. Duo pertinax cotidieque at, eum te integre detraxit philosophia, quando dictas mea an. Putent nostrud in per, reque persequeris sea ad. At mei graeci cotidieque neglegentur, id ius omittam commune suscipiantur. Ne his tamquam percipit expetenda, soleat omittam ea sea.\r\n<br><br>\r\nVel et aliquam molestie, vix ea noster verear. Sea ei tollit urbanitas. Ne erat nemore duo, alia probatus vis at, cibo libris deserunt ea mei. Ex his nonumes dignissim.\r\n<br><br>\r\nHas at quod malis, ad tollit oportere duo. Sint soluta iriure ad eos, fuisset theophrastus et nec. Vero facilis ei mea, porro patrioque consectetuer eu pro. Cu graeco aeterno recusabo cum.\r\n<br><br>\r\nHas ad enim erat vituperata, mei magna fuisset an, sit an numquam singulis. Nec te magna dissentias, dictas eloquentiam sit cu. In sumo conceptam per, suscipit voluptatum ius et, eu mel augue partiendo suavitate. Te dico voluptaria pri, ea mel enim omnium noluisse, sint omnes principes eu quo. Ut commodo utroque mentitum quo, elitr doctus ut mei, quando vocibus ad qui.\r\n<br><br>\r\nIn tritani hendrerit consectetuer duo. Illud errem sed ea, ex eam erant doming viderer. Cum utinam veritus offendit in. Te iusto indoctum conceptam mel. Ei nihil accusam iudicabit nec. Vix id erat prima dissentiunt.\r\n<br><br>\r\nCommodo maiorum dissentiunt usu ne, sint pertinacia sea ut, sed eu perfecto honestatis. No consequat disputationi ius, an wisi iudicabit inciderint pro, diam atqui ei mea. Ea quis sumo elit eos, eam vero consequat contentiones ei. Has ex omnesque partiendo posidonium, pri ea natum fugit libris.\r\n<br><br>\r\nUsu unum quando deseruisse at. Eu qui graecis suavitate, minim pertinax ex eum. Id vis impedit delectus perfecto, cum illud fastidii aliquando ea, summo novum atomorum vis te. Sed solum putent id, usu cu nemore debitis oportere, nihil utroque principes mei ea.\r\n<br><br>\r\nIus ad verear pertinax evertitur, cu qui rebum inani malorum, dicit soluta corrumpit nam an. Id placerat ocurreret vis, ut cum fugit fastidii evertitur, nam labitur periculis at. Eum cu interpretaris necessitatibus. Et exerci oportere sit, quem ferri evertitur mel an.\r\n<br><br>\r\nNam id voluptaria disputando. Vim ne agam assentior, agam intellegat concludaturque eu vix. Eam ad alienum albucius, te duo oratio doming hendrerit. Pro et assum audiam deseruisse, qui vitae viderer assentior ne, in sea graeco molestiae. Nam nisl volutpat ad, no vim facer paulo dolores.\r\n<br><br>\r\nEt his solet epicurei. Alienum insolens volutpat ius at, saepe nominavi oporteat an ius. Facete civibus ea vix, ad eam perfecto adipiscing reprimique. Quo aperiam adipisci te, ipsum animal eum ex. In meis simul oportere mel, ut modus admodum mel.', '2016-04-02', 'Approve');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `CommentID` int(11) NOT NULL,
  `BlogID` int(11) NOT NULL,
  `User` varchar(20) NOT NULL,
  `Comment` varchar(500) NOT NULL,
  `DateAdded` date NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`CommentID`, `BlogID`, `User`, `Comment`, `DateAdded`, `Status`) VALUES
(9, 1, 'Kristel', 'brilliante', '2016-03-24', 'Approve'),
(10, 1, 'Ivy Dela Merced', 'This site is the best when it comes to showcasing pets and selling them online. Love it!', '2016-03-24', 'Approve'),
(12, 2, 'Joseph', 'Thank you for keeping us updated!', '2016-03-24', 'Approve'),
(15, 1, 'adaada', 'ad', '2016-03-31', 'Pending'),
(16, 1, 'adsad', 'sdsd', '2016-04-01', 'Pending'),
(17, 1, 'sd', 'sds', '2016-04-02', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `DeliveryNo` int(11) NOT NULL,
  `OrderNo` int(11) NOT NULL,
  `DateDelivered` date NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`DeliveryNo`, `OrderNo`, `DateDelivered`, `Status`) VALUES
(17, 22, '2016-04-03', 'Pending'),
(18, 23, '2016-04-03', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE `orderdetail` (
  `RefNo` int(11) NOT NULL,
  `OrderNo` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `PetID` int(11) NOT NULL,
  `SuppliesID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Amount` double NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`RefNo`, `OrderNo`, `UserID`, `PetID`, `SuppliesID`, `Quantity`, `Amount`, `Status`) VALUES
(38, 22, 2, 10, 0, 1, 3231, 'Processing'),
(39, 22, 2, 1, 0, 2, 244, 'Processing'),
(40, 22, 2, 17, 0, 1, 0, 'Processing'),
(41, 23, 2, 1, 0, 1, 122, 'Processing'),
(42, 23, 2, 10, 0, 1, 3231, 'Processing');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderNo` int(11) NOT NULL,
  `DateOrdered` date NOT NULL,
  `PaymentMethod` varchar(50) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderNo`, `DateOrdered`, `PaymentMethod`, `Status`) VALUES
(22, '2016-04-03', 'Cash on Delivery', 'Pending'),
(23, '2016-04-03', 'Cash on Delivery', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `pet`
--

CREATE TABLE `pet` (
  `PetID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `Breed` varchar(50) NOT NULL,
  `Price` double NOT NULL,
  `Available` int(11) NOT NULL,
  `PetBirthdate` date NOT NULL,
  `Description` varchar(200) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `PetName` varchar(50) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Reason` varchar(500) NOT NULL,
  `DateSold` date NOT NULL,
  `Image` varchar(400) NOT NULL,
  `Image2` varchar(400) NOT NULL,
  `Image3` varchar(400) NOT NULL,
  `IsFeatured` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pet`
--

INSERT INTO `pet` (`PetID`, `CategoryID`, `Breed`, `Price`, `Available`, `PetBirthdate`, `Description`, `StatusID`, `UserID`, `PetName`, `Quantity`, `Reason`, `DateSold`, `Image`, `Image2`, `Image3`, `IsFeatured`) VALUES
(1, 1, 'Doberman Pinscher', 122, 2, '2015-12-10', 'sddgf', 1, 4, 'Dobby', 0, 'aa', '2016-03-27', 'images/Pets/doberman-pinscher.jpg', 'images/Pets/doberman-pinscher2.jpg', 'images/Pets/doberman-pinscher.jpg', 'Yes'),
(10, 1, 'Bulldog', 3231, 3, '2015-09-11', 'fsfsf', 1, 100, '', 0, '', '2016-03-18', 'images/Pets/bulldog.jpg', 'images/Pets/bulldog2.jpg', 'images/Pets/bulldog.jpg', 'Yes'),
(12, 1, 'Shith-Tzu', 693, 2, '2015-09-11', 'fsfsf', 1, 8, 'Joseph', 0, '', '2016-03-18', 'images/Pets/shith-tzu3.jpg', 'images/Pets/shith-tzu.jpg', 'images/Pets/shith-tzu3.jpg', 'Yes'),
(13, 1, 'Burnese-Mountain', 100, 1, '2015-09-11', 'fsfsf', 1, 8, 'Marvin', 0, '', '2016-03-18', 'images/Pets/bernese-mountain.jpg', 'images/Pets/bernese-mountain2.jpg', 'images/Pets/bernese-mountain.jpg', 'Yes'),
(17, 2, 'Persian cat', 0, 1, '1997-07-19', 'Trip lang', 2, 9, 'Kristel', 0, '', '2016-03-18', 'images/Pets/british-shorthair.jpg', '', '', 'Yes'),
(21, 2, 'Sphynx', 0, 1, '1997-02-01', 'cute', 2, 10, 'Jonathan', 0, 'trip lang', '2016-03-20', 'images/Pets/sphynx2.jpg', '', '', 'Yes'),
(22, 1, 'Shith-tzu', 122, 1, '0000-00-00', 'aaaaaaaaaa', 1, 100, 'Krissy', 1, 'aaaaaaaaa', '0000-00-00', 'images/Pets/shith1.jpg', 'images/Pets/shith2.jpg', 'images/Pets/shith3.jpg', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `petcategory`
--

CREATE TABLE `petcategory` (
  `CategoryID` int(11) NOT NULL,
  `Category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `petcategory`
--

INSERT INTO `petcategory` (`CategoryID`, `Category`) VALUES
(1, 'Dogs'),
(2, 'Cats'),
(3, 'Fish'),
(4, 'Birds'),
(5, 'Horses'),
(6, 'Invertebrates'),
(7, 'Poultry'),
(8, 'Rabbits'),
(9, 'Reptiles'),
(10, 'Rodents');

-- --------------------------------------------------------

--
-- Table structure for table `petstatus`
--

CREATE TABLE `petstatus` (
  `StatusID` int(11) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `petstatus`
--

INSERT INTO `petstatus` (`StatusID`, `Status`) VALUES
(1, 'FOR SALE'),
(2, 'FOR ADOPTION');

-- --------------------------------------------------------

--
-- Table structure for table `petsupplies`
--

CREATE TABLE `petsupplies` (
  `SuppliesID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `ProductName` varchar(30) NOT NULL,
  `SuppliesCat` varchar(30) NOT NULL,
  `Brand` varchar(30) NOT NULL,
  `Price` double(30,2) NOT NULL,
  `Available` int(11) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Image` varchar(400) NOT NULL,
  `Image2` varchar(400) NOT NULL,
  `Image3` varchar(400) NOT NULL,
  `IsFeatured` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `petsupplies`
--

INSERT INTO `petsupplies` (`SuppliesID`, `CategoryID`, `ProductName`, `SuppliesCat`, `Brand`, `Price`, `Available`, `Description`, `Image`, `Image2`, `Image3`, `IsFeatured`) VALUES
(1, 1, 'House', '', '', 6430.00, 0, 'nnnnnnnn', 'images/OtherProducts/house1.jpeg', '', '', 'Yes'),
(2, 1, 'Bones', '', '', 2060.00, 0, 'nnnnnnnn', 'images/OtherProducts/dog2.jpeg', '', '', 'Yes'),
(3, 1, 'Treats', '', '', 200.00, 0, 'nnnnnnnn', 'images/OtherProducts/dog1.jpeg', '', '', 'Yes'),
(4, 1, 'Collar', '', '', 2700.00, 0, 'nnnnnnnn', 'images/OtherProducts/collar.jpeg', '', '', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `ReviewID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `PetID` int(11) NOT NULL,
  `SuppliesID` int(11) NOT NULL,
  `ReviewTitle` varchar(80) NOT NULL,
  `Review` varchar(200) NOT NULL,
  `DateAdded` date NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`ReviewID`, `UserID`, `PetID`, `SuppliesID`, `ReviewTitle`, `Review`, `DateAdded`, `Status`) VALUES
(1, 1, 0, 2, '', 'wow', '2016-03-27', 'Approve'),
(2, 3, 0, 2, '', 'amazing', '2016-03-27', 'Approve'),
(3, 5, 10, 0, '', 'nice', '2016-03-27', 'Approve'),
(4, 7, 10, 0, '', 'cool', '2016-03-27', 'Approve');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `UserListID` int(11) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `ContactNo` varchar(20) NOT NULL,
  `Photo` varchar(200) NOT NULL,
  `AdditionalInfo` varchar(300) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserListID`, `LastName`, `FirstName`, `Address`, `ContactNo`, `Photo`, `AdditionalInfo`, `Status`) VALUES
(1, 1, 'Manalo', 'Joseph', 'Cavite', '111', 'images/Customers/joseph.jpg', '', ''),
(2, 2, 'Bautista', 'Jonathan', '114 Upper Banlat, Tandang Sora, QC', '09111111111', 'images/Customers/jonathan.jpg', 'as', 'Active'),
(3, 3, 'Dacuag', 'Marvin', 'Novaliches', '111', 'images/Customers/marvin.jpg', '', ''),
(4, 4, 'Delamerced', 'Ivy', 'Paranaque', '111', 'images/Customers/bp.png', '', ''),
(5, 5, 'Uy', 'Kristel', 'Taft Ave.', '111', 'images/Customers/kristel.jpg', 'sas', 'Active'),
(6, 6, 'Felipe', 'JP', 'Paco', '111', 'images/Customers/bp.png', '', ''),
(7, 7, 'Samaniego', 'Kervin', 'Cavite', '111', 'images/Customers/bp.png', '', ''),
(8, 8, 'Liwanag', 'Reuel', 'Caloocan', '111', 'images/Customers/bp.png', '', ''),
(10, 10, 'Manalo', 'Joseph', '449 Niog', '09051484406', 'images/Customers/bp.png', 'nice', 'Active'),
(11, 11, 'Manalo', 'Joseph', '449 Niog Talaba', '09123', 'images/Customers/bp.png', '', ''),
(100, 100, 'PH', 'PetLane', '', '', 'images/Customers/bp.png', '', ''),
(101, 15, 'Bautista', 'Joy', 'aaaaa', '11111', 'images/Customers/bp.png', '', ''),
(943, 9, 'Suarez', 'Japheth', 'Marikina', '111', 'images/Customers/bp.png', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `userlist`
--

CREATE TABLE `userlist` (
  `UserListID` int(11) NOT NULL,
  `UserTypeID` int(11) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `DateAdded` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userlist`
--

INSERT INTO `userlist` (`UserListID`, `UserTypeID`, `Email`, `Username`, `Password`, `DateAdded`) VALUES
(1, 1, 'seph@benilde.edu.ph', 'seph', 'pass', '2016-03-16'),
(2, 3, 'athan@yahoo.com.ph', 'athan', 'pass', '0000-00-00'),
(3, 2, 'vin@benilde.edu.ph', 'vin', 'pass', '0000-00-00'),
(4, 3, 'ivy@benilde.edu.ph', 'ivy', 'pass', '0000-00-00'),
(5, 3, 'kristel@benilde.edu.ph', 'kristel', 'pass', '0000-00-00'),
(6, 3, 'jp@benilde.edu.ph', 'jp', 'pass', '0000-00-00'),
(7, 3, 'kervs@benilde.edu.ph', 'kervs', 'pass', '0000-00-00'),
(8, 3, 'reuel@benilde.edu.ph', 'ray', 'pass', '0000-00-00'),
(9, 3, 'japh@benilde.edu.ph', 'japh', 'pass', '0000-00-00'),
(10, 1, 'jo@benilde.edu.ph', 'jos', 'pass', '0000-00-00'),
(11, 3, 'seph@benilde.edu.ph', 'joseph', 'pass', '0000-00-00'),
(12, 2, 'legit@benilde.edu.ph', 'legit', 'pass', '0000-00-00'),
(13, 2, 'baut@benilde.edu.ph', 'baut', 'pass', '0000-00-00'),
(14, 2, 'maganda@benilde.edu.ph', 'maganda', 'pass', '0000-00-00'),
(15, 3, 'asasa@yahoo.com', 'joy', 'pass', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE `usertype` (
  `UserTypeID` int(11) NOT NULL,
  `UserType` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usertype`
--

INSERT INTO `usertype` (`UserTypeID`, `UserType`) VALUES
(1, 'Administrator'),
(2, 'Veterinarian'),
(3, 'Customer');

-- --------------------------------------------------------

--
-- Table structure for table `veterinarian`
--

CREATE TABLE `veterinarian` (
  `VeterinarianID` int(11) NOT NULL,
  `UserListID` int(11) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `ContactNo` varchar(20) NOT NULL,
  `Hospital` varchar(100) NOT NULL,
  `Degree` varchar(50) NOT NULL,
  `SchoolGraduated` varchar(100) NOT NULL,
  `Experience` int(11) NOT NULL,
  `BoardCertification` varchar(50) NOT NULL,
  `Awards` varchar(200) NOT NULL,
  `Photo` varchar(200) NOT NULL,
  `AdditionalInfo` varchar(300) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `veterinarian`
--

INSERT INTO `veterinarian` (`VeterinarianID`, `UserListID`, `LastName`, `FirstName`, `Address`, `ContactNo`, `Hospital`, `Degree`, `SchoolGraduated`, `Experience`, `BoardCertification`, `Awards`, `Photo`, `AdditionalInfo`, `Status`) VALUES
(1, 12, 'Legit', 'Doc', 'Talaba men', '0999', 'UP Hospital', 'Master''s in Vet', 'Upian nang lata', 2, 'pasado pre', 'Mr. Universe', 'images/Veterinarians/vet1.jpg', 'wala akong masabi', 'Active'),
(2, 13, 'Baut', 'Than', '091 Tandang', '092222', 'Makati Med', 'Highest', 'New Era', 5, 'board vet', 'pinakapogi ', 'images/Veterinarians/vet2.jpg', 'nooooooo', 'Active'),
(3, 14, 'Maganda', 'Siya', '123 Sterling', '0911', 'Makati Med', 'Masters in Pet', 'UP Diliman', 3, 'Passer of Board', 'Ms. Universe 2018', 'images/Veterinarians/vet3.jpg', 'walaaahehehe@asd', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`AppointmentID`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`BlogID`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`CommentID`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`DeliveryNo`);

--
-- Indexes for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD PRIMARY KEY (`RefNo`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderNo`);

--
-- Indexes for table `pet`
--
ALTER TABLE `pet`
  ADD PRIMARY KEY (`PetID`);

--
-- Indexes for table `petcategory`
--
ALTER TABLE `petcategory`
  ADD PRIMARY KEY (`CategoryID`);

--
-- Indexes for table `petstatus`
--
ALTER TABLE `petstatus`
  ADD PRIMARY KEY (`StatusID`);

--
-- Indexes for table `petsupplies`
--
ALTER TABLE `petsupplies`
  ADD PRIMARY KEY (`SuppliesID`),
  ADD UNIQUE KEY `ProductID` (`SuppliesID`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`ReviewID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `userlist`
--
ALTER TABLE `userlist`
  ADD PRIMARY KEY (`UserListID`);

--
-- Indexes for table `usertype`
--
ALTER TABLE `usertype`
  ADD PRIMARY KEY (`UserTypeID`),
  ADD UNIQUE KEY `UserTypeID` (`UserTypeID`);

--
-- Indexes for table `veterinarian`
--
ALTER TABLE `veterinarian`
  ADD PRIMARY KEY (`VeterinarianID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `AppointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `BlogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `CommentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `DeliveryNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `orderdetail`
--
ALTER TABLE `orderdetail`
  MODIFY `RefNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `pet`
--
ALTER TABLE `pet`
  MODIFY `PetID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `petcategory`
--
ALTER TABLE `petcategory`
  MODIFY `CategoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `petstatus`
--
ALTER TABLE `petstatus`
  MODIFY `StatusID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `petsupplies`
--
ALTER TABLE `petsupplies`
  MODIFY `SuppliesID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `ReviewID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=944;
--
-- AUTO_INCREMENT for table `userlist`
--
ALTER TABLE `userlist`
  MODIFY `UserListID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `veterinarian`
--
ALTER TABLE `veterinarian`
  MODIFY `VeterinarianID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
